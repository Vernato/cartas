function solution(A) {
  return "Solution";
}

function fibonacci() {
  return "Fibonacci";
}

function getWinner(A, B) {
  return "getWinner";
}

export { solution, fibonacci, getWinner };
