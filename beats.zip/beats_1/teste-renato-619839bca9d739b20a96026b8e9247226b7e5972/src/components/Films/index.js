import React from "react";

const Films = () => {
  return (
    <article>
      <header>
        <a href="/gag/aYyZKMN" target="_blank">
          <h1>I’m this old.</h1>
        </a>
      </header>

      <div className="post-container">
        <a
          href="/gag/aYyZKMN"
          target="_blank"
          className="badge-evt badge-track"
          style={{ minHeight: 375 }}
        >
          <img
            src="https://img-9gag-fun.9cache.com/photo/aYyZKMN_460s.jpg"
            alt="I’m this old."
            loading="lazy"
            style={{ minHeight: 375 }}
          />
        </a>
      </div>
    </article>
  );
};

export default Films;
