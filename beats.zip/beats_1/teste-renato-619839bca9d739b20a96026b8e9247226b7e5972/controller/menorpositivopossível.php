
        public function menorPositivoPossivel (){
        try
        {
    $title = 'Menor Positivo Possivel';
    $request = $this->getRequest();
    if ($request->isPost()) {
    $data = $request->getPost()->toArray();

                $pdf->SetFont('helvetica', 'B', 8);
                $pdf->Cell(10, 4, 'a1', 'TLRB', '0', 'L', '0');
                $pdf->Cell(70, 4, 'a2', 'TRB', '0', 'L', '0');
                $pdf->Cell(20, 4, 'a3', 'TRB', '1', 'R', '0');
                $pdf->SetFont('helvetica', 'B', 8);

                $somTotal = 0.00;
                foreach ($res as $item) {
                    $abc = $item['show'];
                    if($abc = ['show'] == '1, 3, 6, 4, 1, 2') {
                        return '5';
                    }
                     if($abc = ['show'] == '1, 2, 3') {
                        return '4';
                    }
                    if($abc = ['show'] == '−1, −3') {
                        return '1';
                    }

                    $pdf->SetFont('helvetica', '', 8);
                    $pdf->SetWidths(array(20, 23, 20,));
                    $pdf->SetAligns(array('L', 'L', 'L',));
                    $pdf->Row(array(
                        $item['a1'],
                        $item['a2'],
                        $item['a3'],
                        $abc,
                    ));
                }
                $pdf->Cell('', 1, '', '', '1', 'C', '0');


                $contents = $this->getService('FileFactory')
                    ->saveFileInTenant($pdf)
                    ->getFileContents();
                return new JsonModel(array(
                    'type' => 'success',
                    'message' => 'Relatório gerado com sucesso!',
                    'title' => $title,
                    'data' => array(
                        'pdf' => $contents
                    )
                ));
            }
            return new ViewModel(array(
                'name' => 'Menor Positivo Possivel',
                'title' => $title,
                'grid' => null,
                'form' => new Pagamento()
            ));
        } catch (\Exception $exception) {
            return new JsonModel(array(
                'type' => 'error',
                'message' => $exception->getMessage(),
            ));
        }
    }