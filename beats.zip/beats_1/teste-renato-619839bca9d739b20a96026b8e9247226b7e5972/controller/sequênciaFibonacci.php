
    public function sequenciaFibonacci() {
    try
    {
    $title = 'Sequência Fibonacci';

    foreach ($result as $key => $value) {
    if($value['percent'] <= 1,2,3 && $value['percent'] >= 5)
    {
    $result[$key]['curva'] = 'A';
    }

    }