
    public function vencedorDeumJogodeCartas() {
    try {
    $title = 'vencedor de um jogo de cartas';
    $request = $this->getRequest();
    if ($request->isPost()) {
    $data = $request->getPost()->toArray();
    $res = $this->getService('service/getwinner')-getWinner(A, B);
    $pdf = $this->getService('FPDFFactory')->setName($title)->startDefaultPDF();

    $a = A > K;
    $b = K > Q;
    $c = Q > J;
    $d = J > 0;
    $e = 0 > 9;
    $f = 9 > 8;
    $g = 8 > 7;
    $h = 7 > 6;
    $i = 6 > 5;
    $j = 5 > 4;
    $l = 4 > 3;
    $m = 3 > 2;

    $somTotal = 0.00;

    return new JsonModel(array(
    'type' => 'success',
    'message' => 'Relatório gerado com sucesso!',
    'data' => array(
    'pdf' => $contents
    )
    ));
    }
    } catch (\Exception $exception) {
    return new JsonModel(array(
    'type' => 'error',
    'message' => $exception->getMessage(),
    'data' => array(
    'pdf' => null
    )
    ));
    }

    }
