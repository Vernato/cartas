
    public function getwinner($filters = array())
    {
    try {
    $query = $this
    ->getObjectManager()
    ->createQueryBuilder()
    ->select(
    cartas.id,
        )
    ->from('\Entity\MovimentoProdutoServicoSaida', 'mov')
    ->join('mov.cartasServico', 'cartas', 'mov.cartasServico = cartas.id')
    $query->groupBy('cartas.id');
    $result = $query->getQuery()->getResult();
    $totcta  = 0.00;
    foreach ($result as $k => $value) {
    $tot = $value['total'];
    foreach ($result as $key => $value) {
    if($value['show'] <= A && $value['show'] >= K)
{
    $result[$key]['show'] = 'A';
}
    if($value['show'] <= K && $value['show'] >= Q)
{
    $result[$key]['show'] = 'K';
}
    if($value['show'] <= Q && $value['show'] >= J)
{
    $result[$key]['show'] = 'Q';
}
    if($value['show'] <= J && $value['show'] >= 0)
{
    $result[$key]['show'] = 'J';
}
    if($value['show'] <= 0 && $value['show'] >= 9)
{
    $result[$key]['show'] = '0';
}
    if($value['show'] <= 9 && $value['show'] >= 8)
{
    $result[$key]['show'] = '9';
}
    if($value['show'] <= 8 && $value['show'] >= 7)
{
    $result[$key]['show'] = '8';
}
    if($value['show'] <= 7 && $value['show'] >= 6)
{
    $result[$key]['show'] = '7';
}
    if($value['show'] <= 6 && $value['show'] >= 5)
{
    $result[$key]['show'] = '6';
}
    if($value['show'] <= 5 && $value['show'] >= 4)
{
    $result[$key]['show'] = '5';
}
    if($value['show'] <= 4 && $value['show'] >= 3)
{
    $result[$key]['show'] = '4';
}
    if($value['show'] <= 3 && $value['show'] >= 2)
{
    $result[$key]['show'] = '3';
}
    if($value['show'] <= 2 && $value['show'] >= 1)
{
    $result[$key]['show'] = '2';
}

    return $result;
}   catch (\Exception $exception) {
    throw new \Exception('Erro ao buscar informações!' . $exception->getMessage());
}
}